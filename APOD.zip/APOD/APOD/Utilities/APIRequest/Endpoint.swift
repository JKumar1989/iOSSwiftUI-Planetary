//
//  Endpoint.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation

///
/// API Endpoint
/// 
struct Endpoint: RawRepresentable, Hashable {
	//MARK: - Constants
	
	/// plantary List/ detail
	static let plantary  = Endpoint(rawValue: "/planetary/apod")
	
	
	//MARK: - Properties
	var rawValue: String

	///
	/// Specifies the API Key  for the APOD  API
	///
	///
	var apiKey: String {
		"5LquIng3MJwMKoodIStkbl18Ba2ZUusx4wE9P5xo"
	}

	///
	/// Specifies the `nasa` API base path
	///
	var host: String {
		"api.nasa.gov"
	}

	///
	/// Specifies the `nasa` API  path
	///
	var path: String {
		rawValue
	}
}

extension Endpoint {
	//MARK: - Properties


	//MARK: -

	///
	///  make Engage Module request parameter with additional parameters
	/// - Parameters:
	///   - theParameters: additional parmeters are additional list of parameters for sending parmeter with  default request parameters, additional parameters are  optional
	/// - Returns: list request parameters
	///
	func requestParameters(additionalParameters theParameters: QueryParameters = []) -> QueryParameters {
		var parameters = QueryParameters(arrayLiteral: QueryParameter(name: "api_key", value: apiKey))
		if theParameters.count > 0 {
			parameters.append(contentsOf: theParameters)
		}
		return parameters
	}
	
}
