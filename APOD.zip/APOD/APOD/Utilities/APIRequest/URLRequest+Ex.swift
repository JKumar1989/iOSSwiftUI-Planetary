//
//  URLRequest+Ex.swift
//  APOD
//
//  Created by Jitendra kumar on 15/08/22.
//

import Foundation

public extension URLRequest {
	
	
	///
	/// add and update request hader based on key and value if not exsiting same value of key then update value using `setValue(: _,forHTTPHeaderField: _) ` Or else Add new request header key and value using a`ddValue(: _,forHTTPHeaderField: _) `'
	/// - Parameters:
	///   - value: the request hader value of reqeust header key
	///   - key: reqeust header key
	/// - Returns:  map Request `URLRequest`
	///
	@discardableResult
	mutating func add(value : String, forKey key: String) -> Self {
		if hasContains(forKey: key, value: value) {
			setValue(value, forHTTPHeaderField: key)
		} else {
			addValue(value, forHTTPHeaderField: key)
		}
		return self
	}

	///
	/// has contains Key and value in `allHTTPHeaderFields`
	/// - Parameter key:  header key name
	/// - Returns: A Contains Bool`
	///
	func hasContains(forKey key: String) -> Bool {
		hasContains(forKey: key, value: "")
	}
	
	///
	/// has contains Key and value in `allHTTPHeaderFields`
	/// - Parameters:
	///   - key: header key name
	///   - aValue: header value repective of key
	/// - Returns: `A Contains Bool`
	///
	func hasContains(forKey key: String, value aValue: String) -> Bool {
		let theValue  = aValue.isEmpty ? value(forHTTPHeaderField: key) ?? "" : aValue
		return allHTTPHeaderFields?.contains(where: {$0.key.localizedCaseInsensitiveContains(key) && $0.value.localizedCaseInsensitiveContains(theValue)}) ?? false
	}

	///
	/// `"Content-Type"` Header Type
	/// - Parameter value: the value of header key `"Content-Type"`
	/// - Returns:  map Request `URLRequest`
	///
	@discardableResult
	mutating func contentType(value: String) -> Self  {
		add(value: value, forKey: "Content-Type")
	}
	
	///
	/// `"Accept-Type"` Header Type
	/// - Parameter value: the value of header key `"Accept-Type"`
	/// - Returns: Map Request `URLRequest`
	///
	@discardableResult
	mutating func acceptType(value: String) -> Self  {
		add(value: value, forKey: "Accept-Type")
	}
	
	@discardableResult
	mutating func acceptTypeJSON()  -> Self {
		acceptType(value: "application/json")
	}
	
	@discardableResult
	mutating func contentTypeJSON() -> Self  {
		contentType(value: "application/json")
	}
}

//MARK: -

public extension HTTPURLResponse {
	
	var localizedDescription: String {
		networkInterrupt ? Constants.noNetworkMessage.text : HTTPURLResponse.localizedString(forStatusCode: statusCode)
	}
	var urlErrorCode: URLError.Code {
		URLError.Code(rawValue: statusCode)
	}

	var urlError: URLError {
		URLError(code: urlErrorCode, message: localizedDescription)
	}

	/// - `success:` This class of status code range are  `200..<300`
	var success: Bool {
		if case 200..<300 = statusCode {
			return true
		} else {
			return false
		}
	}

	var networkInterrupt: Bool {
		urlErrorCode.networkInterrupt
	}
	
	
}
