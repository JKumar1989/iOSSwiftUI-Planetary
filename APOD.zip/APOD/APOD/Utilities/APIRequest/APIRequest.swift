//
//  APIRequest.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation
import Combine

protocol APIRequest {

	///
	/// The request's API Endpoint.
	///
	var endpoint :Endpoint {get}

	///
	/// the Request parameters: [QueryParameter]
	///
	var parameters : QueryParameters {get}

}

//MARK: -

extension APIRequest {

	//MARK: -
	
	
	///
	/// tthe raw request task perform
	///
	func perform<T: Codable >( _ type: T.Type) -> AnyPublisher<T, Error> {
		return APIManager.shared.perform(request: self, type)
	}

	///
	/// cancel the Running Taks
	///
	func cancelTask() {
		APIManager.shared.cancel(apiRequest: self)
	}
	
}

//MARK: -

extension APIRequest {

	///
	/// the Request Descriptor
	///
	var requestDescriptor: RequestDescriptor {
		RequestDescriptor(endpoint: endpoint)
	}

	///
	/// the API  url Request
	///
	var urlRequest: URL? {
		requestDescriptor.url(parameters: parameters)
	}

}
