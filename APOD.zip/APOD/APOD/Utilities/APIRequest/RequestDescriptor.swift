//
//  RequestDescriptor.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation

///
/// Type that describes a REST API.
///
struct RequestDescriptor : Equatable {

	//MARK: - Constant

	///
	/// The secure  scheme subcomponent of the URL.
	///
	static let urlScheme = "https"
	
	//MARK: Properties
	
	///
	/// REST API host.
	///
	let host : String
	
	///
	/// Path to the API.
	///
	let path : String

	///
	/// The scheme subcomponent of the URL.
	///
	var scheme: String = urlScheme
	
	//MARK: - Instance
	
	///
	/// the create `RequestDescriptor`
	/// - Parameters:
	///   - aHost: the host name of URL
	///   - aPath: the Request path of url
	///   - anAdditional: the additional Path of URL
	///
	init(host aHost: String,
		 path aPath: String,
		 scheme aScheme : String = urlScheme,
		 additionalPath anAdditional: String = "") {
		host = aHost
		path = anAdditional.isEmpty ? aPath : aPath + anAdditional
	}

	///
	/// the create `RequestDescriptor`
	/// - Parameters:
	///   - endpoint: the Endpoint of URL
	///   - anAdditional: the additional Path of URL
	///
	init(endpoint: Endpoint,
		 additionalPath anAdditional: String = "") {
		let hostType: String = endpoint.host
		let path: String = endpoint.path
		self.init(host: hostType, path: path, additionalPath: anAdditional)
	}

	///
	/// the obtain the URLRequest base on Query Parameter
	/// - Parameter aParametersArray: the Query Parameter
	/// - Returns: the url request
	/// 
	func urlRequest(parameters aParametersArray: QueryParameters) -> URLRequest? {
		guard let theUrl = url(parameters: aParametersArray) else { return nil }
		return URLRequest(url: theUrl)
	}

	///
	/// the obtain the URL base on Query Parameter
	/// - Parameter aParametersArray: the Query Parameter
	/// - Returns: the url
	/// 
	func url(parameters aParametersArray: QueryParameters) -> URL? {
		let theNormalizedPath = path
		let theQueryItems = aParametersArray.map { $0.queryItem}
		let theNormalizedQueryItems = theQueryItems.isEmpty ? nil : theQueryItems
		let aUrl = urlQuery(withHost: host, path: theNormalizedPath, queryItems: theNormalizedQueryItems)
		return aUrl
		
	}
	
	//MARK: - URLs
	
	///
	/// Obtains a URL built from the given components.
	///
	/// - parameter aHost: A host.
	/// - parameter aPath: A path.
	/// - parameter aQueryItemsArray: Any query items.
	///
	/// - returns: A `URL`.
	///
	///
	func urlQuery(withHost aHost: String,
				  path aPath: String,
				  queryItems aQueryItemsArray: [URLQueryItem]?) -> URL? {
		var theURLComponents = URLComponents()
		theURLComponents.scheme = scheme
		theURLComponents.host = aHost
		theURLComponents.path = aPath
		theURLComponents.queryItems = aQueryItemsArray
		return theURLComponents.url
	}

	
}
