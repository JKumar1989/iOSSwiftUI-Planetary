//
//  QueryParameter.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation


typealias QueryParameters = [QueryParameter]

//MARK: -

///
/// Type representing a parameter for a request.
///
struct QueryParameter : Equatable {
	
	//MARK: Properties
	
	///
	/// Parameter's name.
	///
	let name : String

	///
	/// Parameter's original value which could be a host manager placeholder.
	///
	private let internalValue : String
	
	///
	/// Parameter's value.
	///
	var value : String {
		internalValue
	}

	///
	/// Obtains a query item for this `QueryParameter`.
	///
	var queryItem : URLQueryItem {
		URLQueryItem(name: name, value: value)
	}
	
	//MARK: - Instance
	
	///
	/// Initializes an `QueryParameter`.
	///
	/// - parameter aName: Parameter's name.
	/// - parameter aValue: Parameter's value.
	///
	init(name aName: String,
		 value aValue: String) {
	
		name = aName
		internalValue = aValue
	}
}


