//
//  Constants.swift
//  APOD
//
//  Created by Jitendra kumar on 11/08/22.
//

import Foundation

struct Constants: RawRepresentable {
	
	///
	/// Planetar Request error title
	///
	static let requestErrorTitle = Constants(rawValue: "Planetar Reqeust Error")

	///
	/// no network connection or lost title
	///
	static let noNetworkTitle = Constants(rawValue: "Internet is not available")

	///
	/// no network connection or lost message
	///
	static let noNetworkMessage = Constants(rawValue: "We are having difficulties connecting you to the internet. Please check your network connection and try again")
	
	
	var rawValue: String
	
	var text: String {
		rawValue
	}
}
