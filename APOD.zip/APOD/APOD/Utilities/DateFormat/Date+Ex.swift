//
//  Date+Ex.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation
extension Date {

	///
	/// the current Date [Today]
	///
	static var today : Date {
		Date()
	}

	///
	/// Obtains Previous Date from Date as per Days [30]
	/// - Parameter days: the number of days
	/// - Returns: the Previous Date from date
	///
	func date(daysFromToday days : Int = 30) -> Date {
		Calendar.current.date(byAdding: .day, value: -days, to: .today) ?? .today
	}
	var year: Int {
		Calendar.current.component(.year, from: self)
	}
	var month: Int {
		Calendar.current.component(.month, from: self)
	}
	var day: Int {
		Calendar.current.component(.day, from: self)
	}

	
}
extension Calendar {
	
	var planteryMinDate: Date {
		let startComponents = DateComponents(year: 1995, month: 6, day: 16)
		return date(from: startComponents)!
	}
	var planteryDateRange: ClosedRange<Date> {
		planteryMinDate
		...
		Date.today.date(daysFromToday: 1)
	}
}

