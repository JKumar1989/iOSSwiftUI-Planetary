//
//  NetworkMonitor.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation
import Network

final class NetworkMonitor : ObservableObject {
	
	//MARK: - Properties
	

	///
	/// Intance Object of `NWPathMonitor`
	///
	private let monitor = NWPathMonitor()
	
	///
	/// `DispatchQueue` on which network Monitor will update.
	///
	private let monitorQueue: DispatchQueue = DispatchQueue(label: "APOD.Network.MonitorQueue",qos: .background)

	///
	/// has Internet connection stablished or not
	///
	@Published private(set) var isConnected: Bool = false
	
	///
	/// The current  network Monitor Status `[.requiresConnection/.satisfied/unsatisfied]`
	///
	@Published private(set) var monitorStatus: MonitorStatus = .requiresConnection

	///
	/// has Internet nonitoring is stared or not
	///
	@Published private(set) var isMonitoring: Bool = false
	
	///
	/// On Change the network connection status `Online/Offline`
	///
	@Published var onListener: ((_ isConnected: Bool) -> Void)?

	//MARK: - Instance
	
	init() {
		start()
	}
	
	
	deinit {
		stop()
	}
	
}

//MARK: -
extension NetworkMonitor {
	
	///
	/// Starts monitoring path changes, and sets a queue on which to deliver path events.
	///
	func start() {
		if !isMonitoring {
			monitor.start(queue: monitorQueue)
			isMonitoring = true
		}
		monitor.pathUpdateHandler = { path in
			self.setStatus(path)
		}
	}
	
	///
	/// the Internet connection monitoring stops
	///
	func stop() {
		monitor.cancel()
		isMonitoring = false
		isConnected = false
		monitorStatus = .requiresConnection
	}
	
	//MARK: - Properties
	
	///
	/// A list of all interfaces available to the path, in order of preference. `[NWInterface]`
	///
	var availableInterfaces: [NWInterface] {
		monitor.currentPath.availableInterfaces
	}
	
	///
	/// a List of All available interface types ` [NWInterface.InterfaceType] `
	///
	var interfaceTypes: [NWInterface.InterfaceType] {
		availableInterfaces.compactMap({$0.type})
	}
	
	///
	/// a List of All available connection types `[MonitorStatus.ConnectionType]`
	///
	var connectionTypes: [MonitorStatus.ConnectionType] {
		guard isSatisfied else {
			return []
		}
		return interfaceTypes.compactMap({
			let type : MonitorStatus.ConnectionType
			if $0 == .wifi {
				type = .wifi
			} else if $0 == .cellular {
				type = .cellular
			} else if $0 == .wiredEthernet {
				type =  .ethernet
			} else if $0 == .other {
				type =  .other
			} else {
				type = .unknown
			}
			return type
		})
	}
	
	///
	/// A list of gateways configured on the interfaces available to a path.
	///
	var interfaceGateways: [NWInterface] {
		monitor.currentPath.gateways.compactMap({$0.interface})
	}
	
	///
	/// The path is available to establish connections and send data.
	///
	@objc var isSatisfied: Bool {
		monitorStatus.isSatisfied
	}
	
	///
	///  A Boolean indicating whether the  path uses an interface that is considered expensive,  isExpensive is set to true when using cellular data or when using WiFi that is hotspot routed through an iPhone’s cellular connection.
	///
	@objc var isExpensive: Bool {
		monitor.currentPath.isExpensive
	}
	
	///
	/// A Boolean indicating whether the path uses an interface in Low Data Mode.
	///
	var isConstrained: Bool {
		monitor.currentPath.isConstrained
	}
	
	///
	/// whether the network is currently reachable over the `cellular` interface.
	///
	var isCellular: Bool {
		monitorStatus == .satisfied(.cellular)
	}
	
	///
	/// whether the network is currently reachable over the `wifi` interface.
	///
	var isWifi: Bool {
		monitorStatus == .satisfied(.wifi)
	}
	
	///
	/// whether the network is currently reachable over the `wiredEthernet` interface.
	///
	var isEthernet: Bool {
		monitorStatus == .satisfied(.ethernet)
	}
	
	///
	/// whether the network is currently reachable over the `wiredEthernet/.wifi ` interface.
	///
	var isEthernetOrWiFi: Bool {
		isWifi || isEthernet
	}

	///
	/// Network Noniting Status
	/// - Parameter theStatus: the status of `NWPath.Status`
	///
	private func setStatus(_ thePath: NWPath) {
		DispatchQueue.main.async {
			let theStatus = thePath.status
			self.monitorStatus = MonitorStatus(thePath)
			self.connectivity(theStatus)
		}
	}

	///
	/// connectivity status
	/// - Parameter theStatus: the status of `NWPath.Status`
	///
	private func connectivity(_ theStatus: NWPath.Status) {
		isConnected = theStatus == .satisfied && (isCellular || isEthernetOrWiFi)
		onListener?(isConnected)
	}
	
	///
	/// till waits for newtwork connect
	/// - Parameter offline: Indicate network status, e.g., offline mode
	///
	func networkStatusHandler( _ offline: Bool) {
		DispatchQueue.main.async {
			self.connectivity(offline ? .requiresConnection : .satisfied)
		}
	}
	
}

//MARK: -

extension NetworkMonitor {
	
	/// Defines the various states of network Monitoring status.
	enum MonitorStatus: Equatable {
		
		/// The network is reachable `satisfied` on the associated `ConnectionType`.
		case satisfied(ConnectionType)
		
		/// It is unknown whether the network is reachable. The path does not have a usable route. This may be due to a network interface being down, or due to system policy.
		case unsatisfied
		
		/// The network is not reachable. `requiresConnection`The path does not currently have a usable route, but a connection attempt will trigger network attachment.
		case requiresConnection
		
		
		//MARK: -
		
		///
		/// Create MonitorStatus
		/// - Parameter path: The currently available network path observed by the path monitor.
		///
		init(_ path: NWPath) {
			let networkStatus : MonitorStatus
			if path.status == .satisfied {
				networkStatus = .satisfied(ConnectionType(path))
			} else if path.status == .unsatisfied {
				networkStatus = .unsatisfied
			} else {
				networkStatus = .requiresConnection
			}
			self = networkStatus
		}
		
		
		//MARK: - Properties
		
		///
		/// Network Monitior Path Status
		///
		var nwStatus: NWPath.Status {
			if case .requiresConnection = self {
				return .requiresConnection
			} else if case .unsatisfied = self {
				return .unsatisfied
			} else {
				return .satisfied
			}
		}
		
		///
		/// The path is available to establish connections and send data.
		///
		var isSatisfied: Bool {
			nwStatus == .satisfied
		}
		
		///
		/// The path is not available for use.
		///
		var isUnsatisfied: Bool {
			nwStatus == .unsatisfied
		}
		
		///
		/// The path is not currently available, but establishing a new connection may activate the path.
		///
		var isRequiresConnection: Bool {
			nwStatus == .requiresConnection
		}
		
	}
	
}


extension NetworkMonitor.MonitorStatus {
	
	/// Defines the various connection types detected by reachability flags.
	enum ConnectionType : Equatable {
		
		/// A virtual or otherwise unknown interface type
		case other
		
		/// The connection type is either over WiFi.
		case wifi
		
		/// The connection type is a cellular connection.
		case cellular
		
		/// The connection type is either over  wired Ethernet link
		case ethernet
		
		/// The network interface type used for communication over local `loopback` networks.
		case loopback
		
		/// The connection type is  unknown whether
		case unknown
		
		//MARK: -
		
		///
		/// Create Connection Type
		/// - Parameter path: The currently available network path observed by the path monitor.
		///
		init(_ path: NWPath) {
			var networkStatus : ConnectionType
			if path.status == .satisfied {
				if path.usesInterfaceType(.wifi)  {
					networkStatus =  .wifi
					
				} else if path.usesInterfaceType(.cellular) {
					networkStatus = .cellular
					
				} else if path.usesInterfaceType(.wiredEthernet) {
					networkStatus = .ethernet
					
				} else if path.usesInterfaceType(.loopback) {
					networkStatus = .loopback
					
				} else {
					networkStatus = .other
				}
			} else {
				networkStatus =  .unknown
			}
			self = networkStatus
		}
		
		
	}
}
