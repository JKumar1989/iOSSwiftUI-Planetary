//
//  APIManager.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation
import Combine

final class APIManager {
	
	static let shared = APIManager()
	
	@Published var monitor = NetworkMonitor()
	
	// Create a shared URL cache
	private (set) lazy var urlCache: URLCache = {
		let memoryCapacity = 500 * 1024 * 1024; // 500 MB
		let diskCapacity = 500 * 1024 * 1024; // 500 MB
		return URLCache(memoryCapacity:memoryCapacity, diskCapacity: diskCapacity, diskPath: "APIManager_Cache")
	}()
	
	private (set) lazy var session: URLSession = {
		let configuration: URLSessionConfiguration = .default
		configuration.timeoutIntervalForResource = 120
		configuration.waitsForConnectivity = true
		configuration.requestCachePolicy = .returnCacheDataElseLoad
		configuration.urlCache = urlCache
		if monitor.isConnected {
			configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
		}
		return URLSession(configuration: configuration)
	}()

	private init() {
		monitor.start()
	}
	
	//MARK: - Cancel the `running` Request
	
	///
	/// Cancel running request
	/// - Parameter urlString: the request url string
	///
	func cancel(urlString: String) {
		guard let url = URL(string: urlString) else { return  }
		cancel(url: url)
	}
	
	///
	/// Cancel running request
	/// - Parameter url: the url
	///
	func cancel(url: URL) {
		cancel(urlRequest: URLRequest(url: url))
	}

	///
	/// Cancel running request
	/// - Parameter urlRequest: the  request url
	///
	func cancel(urlRequest: URLRequest) {
		session.getAllTasks {
			$0
				.filter({$0.state == .running})
				.filter({$0.originalRequest == urlRequest || $0.currentRequest == urlRequest})
				.forEach({
					$0.cancel()
				})
		}
	}

	///
	/// perform  Raw task request
	/// - Parameters:
	///   - request: the api request type protocol
	///   - completion: the JSON response handler
	/// - Returns:
	///
	func perform<T: Codable>(request : APIRequest, _ type: T.Type,
							 decoder: JSONDecoder = JSONDecoder()) -> AnyPublisher<T, Error> {
		guard let url = request.urlRequest else {
			return Fail(error: NSError(domain: Bundle.main.bundleIdentifier ?? "\(request.endpoint.host)", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid endpoint Request"])).eraseToAnyPublisher()
		}
		debugPrint("Reqeust 👉 \(url.absoluteString)")
		if monitor.isConnected {
			session.configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
		}
		debugPrint("network connection 👉 \(monitor.isConnected  ? "connected" : "not connected")")
		return session.publisher(for: url, type, decoder: decoder, urlCache: urlCache)
			.eraseToAnyPublisher()
	}

}

//MARK: -

extension APIManager  {

	///
	/// cancel the running task request
	/// - Parameter apiRequest: the api Request
	///
	func cancel(apiRequest: APIRequest) {
		if let urlRequest = apiRequest.urlRequest  {
			cancel(url: urlRequest)
		}
	}

}
