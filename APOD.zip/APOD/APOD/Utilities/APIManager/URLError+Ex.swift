//
//  URLError+Ex.swift
//  APOD
//
//  Created by Jitendra kumar on 15/08/22.
//

import Foundation

//MARK: -

public extension URLError {
	
	init(code: Int, message: String) {
		let theCode  = Code(rawValue: code)
		self.init(code: theCode, message: message)
	}
	
	init(code: Code, message: String) {
		self.init(code, userInfo: [NSLocalizedDescriptionKey: message])
	}
	
	///
	/// has current request Interrupt due to nework error
	///
	var networkInterrupt: Bool {
		code.networkInterrupt
	}
	
	///
	/// localized  error  Title
	///
	var localizedTitle : String {
		networkInterrupt ? Constants.noNetworkTitle.text : Constants.requestErrorTitle.text
	}
	
	///
	/// localized error Description  message instance of `localizedDescription`
	///
	var localizedMessage: String {
		networkInterrupt ? Constants.noNetworkMessage.text : localizedDescription
	}
}

public extension URLError.Code  {

	///
	/// has current request Interrupt due to nework error
	///
	var networkInterrupt : Bool {
		
		isCannotFindHost 			||
		isCannotConnectToHost 		||
		isNetworkConnectionLost 	||
		isNotConnectedToInternet 	||
		isInternationalRoamingOff 	||
		isCallIsActive 				||
		isDataNotAllowed
	}
	
	///
	/// - `NSURLErrorCannotFindHost`: The host name for a URL couldn’t be resolved.
	///
	var isCannotFindHost: Bool {
		URLError.Code.cannotFindHost.rawValue == NSURLErrorCannotFindHost
	}
	
	///
	/// - `NSURLErrorCannotConnectToHost`: An attempt to connect to a host failed.
	///
	var isCannotConnectToHost: Bool {
		URLError.Code.cannotConnectToHost.rawValue == NSURLErrorCannotConnectToHost
	}
	
	///
	/// - `NSURLErrorNetworkConnectionLost`: A client or server connection was severed in the middle of an in-progress load.
	///
	var isNetworkConnectionLost: Bool {
		URLError.Code.networkConnectionLost.rawValue == NSURLErrorNetworkConnectionLost
	}
	
	///
	/// - `NSURLErrorNotConnectedToInternet`: A network resource was requested, but an internet connection has not been established and can’t be established automatically.
	///
	var isNotConnectedToInternet: Bool {
		URLError.Code.notConnectedToInternet.rawValue == NSURLErrorNotConnectedToInternet
	}
	
	///
	/// - `NSURLErrorInternationalRoamingOff`: The attempted connection required activating a data context while roaming, but international roaming is disabled.
	///
	var isInternationalRoamingOff: Bool {
		URLError.Code.internationalRoamingOff.rawValue == NSURLErrorInternationalRoamingOff
	}
	
	///
	/// - `NSURLErrorCallIsActive`:  connection was attempted while a phone call was active on a network that doesn’t support simultaneous phone and data communication, such as EDGE or GPRS.``
	///
	var isCallIsActive: Bool {
		URLError.Code.callIsActive.rawValue == NSURLErrorCallIsActive
	}
	
	///
	/// - `NSURLErrorDataNotAllowed`: The cellular network disallowed a connection.
	///
	var isDataNotAllowed: Bool {
		URLError.Code.dataNotAllowed.rawValue == NSURLErrorDataNotAllowed
	}
	
}
