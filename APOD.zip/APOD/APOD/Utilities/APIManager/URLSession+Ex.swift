//
//  URLSession+Ex.swift
//  APOD
//
//  Created by Jitendra kumar on 12/08/22.
//

import Foundation
import Combine

public extension URLSession {

	
	///
	/// The publisher publishes data when the task completes, or terminates if the task fails with an error.
	/// - Parameters:
	///   - url: The URL for which to create a data task.
	///   - type: JSON Decoder model
	///   - decoder: An object that decodes instances of a data type from JSON objects.
	/// - Returns: The publisher that wraps a URL session data task for a given URL.
	///
	func publisher<T: Decodable>(for url: URL,
								 _ type: T.Type,
								 decoder: JSONDecoder = JSONDecoder(),
								 urlCache: URLCache? = nil) -> AnyPublisher<T,Error> {
		var request =  URLRequest(url: url)
		request.contentTypeJSON()
		request.acceptTypeJSON()
		return publisher(for: request, type, decoder: decoder)
	}
	
	///
	/// Returns a publisher that wraps a URL session data task for a given URL request.
	/// - Parameters:
	///   - urlRequest: The URL request for which to create a data task.
	///   - type: JSON Decoder model
	///   - decoder: An object that decodes instances of a data type from JSON objects.
	/// - Returns: The publisher publishes data when the task completes, or terminates if the task fails with an error.
	///
	func publisher<T: Decodable>(for urlRequest: URLRequest,
								 _ type: T.Type,
								 decoder: JSONDecoder = JSONDecoder(),
								 urlCache: URLCache? = nil) -> AnyPublisher<T, Error> {
		
		let sharedPublisher =  dataTaskPublisher(for: urlRequest)
			.tryMap() { element -> Data in
				if let httpResponse = element.response as? HTTPURLResponse {
					if  httpResponse.success {
						if let urlCache = urlCache  {
							urlCache.storeCached(for: urlRequest, data: element.data, response: element.response)
						}
						return element.data
					} else if let urlCache = urlCache, httpResponse.networkInterrupt, let cacheResponse = urlCache.cachedResponse(for: urlRequest)  {
						return cacheResponse.data
					} else {
						throw httpResponse.urlError
					}
					
				} else if !element.data.isEmpty {
					return element.data
				} else {
					throw URLError(.badServerResponse)
				}
			}.decode(type: T.self, decoder: decoder)
		
		return sharedPublisher
			.eraseToAnyPublisher()
		
	}
}




	

	
