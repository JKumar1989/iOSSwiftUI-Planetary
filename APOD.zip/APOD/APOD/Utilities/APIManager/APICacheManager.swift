//
//  APICacheManager.swift
//  APOD
//
//  Created by Jitendra kumar on 14/08/22.
//

import Foundation

extension URLCache {
	
	///
	/// Returns the cached URL response in the cache for the specified URL .
	/// - Parameter url: The URL  whose cached response is desired.
	/// - Returns: The cached URL response for request url, or nil if no response has been cached.
	///
	func cachedResponse(for url: URL) -> CachedURLResponse? {
		let request = URLRequest(url: url)
		return cachedResponse(for: request)
	}

	func storeCached(for url: URL, data: Data, response: URLResponse) {
		let request = URLRequest(url: url)
		storeCached(for: request, data: data, response: response)
	}

	func storeCached<T>(for url: URL, codable: T, response: URLResponse)  where T: Codable {
		do {
			let data = try JSONEncoder().encode(codable)
			storeCached(for: url, data: data, response: response)
		} catch  {
			debugPrint("Encoding URL Cache store Model data Failed : \(error.localizedDescription)")
		}
	}
	
	func storeCached(for urlRequest: URLRequest, data: Data, response: URLResponse) {
		let cachedData = CachedURLResponse(response: response, data: data)
		storeCachedResponse(cachedData, for: urlRequest)
	}
	
	func storeCached<T>(for urlRequest: URLRequest, codable: T, response: URLResponse)  where T: Codable {
		do {
			let data  = try JSONEncoder().encode(codable)
			storeCached(for: urlRequest, data: data, response: response)
		} catch  {
			debugPrint("Encoding URL Cache store Model data Failed : \(error.localizedDescription)")
		}
	}
	
	func removeCached(for url: URL) {
		removeCachedResponse(for: URLRequest(url: url))
	}
}
