//
//  Model.swift
//  APOD
//
//  Created by Jitendra kumar on 11/08/22.
//

import Foundation
import Combine

protocol Model : Identifiable & Codable {
	//Don't do anything
}
