//
//  Planetary.swift
//  APOD
//
//  Created by Jitendra kumar on 09/08/22.
//

import Foundation

struct Planetary : Model {
	
	//MARK: - Properties
	
	
	let id = UUID()
	
	///
	/// the planet name
	///
	let title: String
	
	///
	/// the planet description
	///
	let description: String
	
	///
	/// the planet created Date String
	///
	let createdAt: String
	
	///
	/// the planet  image/ video url
	///
	let mediaUrl: String
	
	///
	/// the planet  image hd url
	///
	let hdurl: String
	
	///
	/// the planet  video thumnail  url
	///
	let videoThumnail: String
	
	///
	/// the planet  media type
	///
	let mediaType: MediaType?
	
	///
	/// created Date
	///
	var date: Date {
		createdAt ~ .podFullDateOnly
	}
	
	///
	/// Obtains Image/video thumbnail  url
	///
	var thumbnailURL: URL? {
		let string =  mediaType == .video  ? videoThumnail : mediaUrl
		return URL(string: string)
	}
	
	//MARK: -
	
	enum CodingKeys: String, CodingKey {
		case createdAt = "date"
		case description = "explanation"
		case hdurl = "hdurl"
		case mediaType = "media_type"
		case title = "title"
		case mediaUrl = "url"
		case videoThumnail = "thumbnail_url"
	}
	
	init(from decoder: Decoder) throws {
		let container = try decoder.container(keyedBy: CodingKeys.self)
		title = try container.decodeIfPresent(String.self, forKey: .title) ?? ""
		description = try container.decodeIfPresent(String.self, forKey: .description) ?? ""
		createdAt = try container.decodeIfPresent(String.self, forKey: .createdAt) ?? ""
		mediaUrl = try container.decodeIfPresent(String.self, forKey: .mediaUrl) ?? ""
		hdurl = try container.decodeIfPresent(String.self, forKey: .hdurl) ?? ""
		videoThumnail = try container.decodeIfPresent(String.self, forKey: .videoThumnail) ?? ""
		mediaType = try? container.decodeIfPresent(MediaType.self, forKey: .mediaType)
		
	}
	
	///
	/// create Planetary Model
	/// - Parameters:
	///   - aTitle: the planet name
	///   - aDescription: the planet description
	///   - aCreatedAt: the planet created Date String
	///   - aMediaUrl: the planet  image/ video url
	///   - imageHDUrl: the planet  image hd url
	///   - videoThumnail: the planet  video thumnail  url
	///   - type: the planet  media type
	///
	init(title aTitle: String,
		 description aDescription: String,
		 createdAt aCreatedAt: String,
		 mediaUrl aMediaUrl: String,
		 hdurl imageHDUrl: String = "",
		 videoThumnail aVideoThumnail: String = "",
		 mediaType type: MediaType = .image) {
		title = aTitle
		description = aDescription
		createdAt = aCreatedAt
		mediaUrl = aMediaUrl
		hdurl = imageHDUrl
		videoThumnail = aVideoThumnail
		mediaType = type
		
	}
}


enum MediaType: String, Codable {
	case image = "image"
	case video = "video"
}


extension Planetary {
	
	static var placeholderList :[Planetary] {
		[
			Planetary(title: "Lubovna Full Moon",
					  description: "On July 13 this well-planned telephoto view recorded a Full Moon rising over Lubovna Castle in eastern Slovakia. The photographer was about 3 kilometers from the castle walls and about 357,000 kilometers from this Full Moon near perigee, the closest point in its elliptical orbit. Known to some as supermoons, full moons near perigee are a little brighter and larger in planet Earth's sky when compared to full moons that occur near the average lunar distance of around 384,000 kilometers. Of course any Full Moon near the horizon can show the effects of refraction over a long sight-line through dense clear atmosphere. In this image, atmospheric refraction creates the slight green flash framed by thin clouds near the top, with a ragged red rim along the bottom edge of July's perigee Full Moon.",
					  createdAt: "2022-07-15",
					  mediaUrl: "https://apod.nasa.gov/apod/image/2207/2022_07_13_Uplnek_Lubovna_1000mm_c1024px.jpg",
					  hdurl: "https://apod.nasa.gov/apod/image/2207/2022_07_13_Uplnek_Lubovna_1000mm_1500px.png",
					  mediaType: .image),
			
			Planetary(title: "Lubovna Full Moon",
					  description: "What it would look like to leave planet Earth? Such an event was recorded visually in great detail by the MESSENGER spacecraft as it swung back past the Earth in 2005 on its way in toward the planet Mercury. Earth can be seen rotating in this time-lapse video, as it recedes into the distance. The sunlit half of Earth is so bright that background stars are not visible. The robotic MESSENGER spacecraft is now in orbit around Mercury and has recently concluded the first complete map of the surface. On occasion, MESSENGER has continued to peer back at its home world. MESSENGER is one of the few things created on the Earth that will never return.  At the end of its mission MESSENGER crashed into Mercury's surface.",
					  createdAt: "2022-08-09",
					  mediaUrl: "https://www.youtube.com/embed/rFDjAfwmWKM?rel=0",
					  videoThumnail: "https://img.youtube.com/vi/rFDjAfwmWKM/0.jpg",
					  mediaType: .video),
			
		]
	}
}
