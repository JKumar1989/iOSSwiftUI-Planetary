//
//  PlanetaryListRequest.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation

final class PlanetaryRequest: APIRequest {
	
	//MARK: - Properties
	
	
	///
	/// the planetary start  date index
	///
	var statDate: String?
	
	///
	/// the planetary end  date index
	///
	var endDate: String?

	///
	/// the  current planetary info date
	///
	var date: String?

	///
	/// the planetary video them nil
	///
	var isThumbs: Bool = true

	///
	/// request endpoint
	///
	var endpoint: Endpoint {
		.plantary
	}
	
	///
	/// the request query Parameters
	///
	var parameters: QueryParameters {
		var qParameters: QueryParameters = [queryParameter(isThumbs.description, forKey: .thumbs)]
		if let theStart = statDate, let theEnd = endDate {
			let dateQuery = [queryParameter(theStart, forKey: .startDate), queryParameter(theEnd, forKey: .endDate)]
			qParameters.append(contentsOf:dateQuery)
		} else if let theDate = date {
			qParameters.append(queryParameter(theDate, forKey: .infoDate))
		}
		return endpoint.requestParameters(additionalParameters: qParameters)
	}
	
	//MARK: - Instance
	 
	///
	/// Create PlanetaryList Reqeust
	/// - Parameters:
	///   - fromDate:  Planetary Start Date
	///   - toDate:  Planetary end Date
	///   - thumbs:  Planetary view thumb enable or not
	///
	init(statDate fromDate: String, endDate toDate : String, isThumbs thumbs: Bool) {
		statDate  = fromDate
		endDate  = toDate
		isThumbs = thumbs
		date = nil
	}

	///
	/// Create Planetary detailReqeust
	/// - Parameters:
	///   - createdAt: Planetary  spefice date of info
	///   - thumbs: Planetary view thumb enable or not
	///
	init(date createdAt: String, isThumbs thumbs: Bool) {
		isThumbs = thumbs
		date = createdAt
		statDate  = nil
		endDate  = nil
	}
	
	
}

//MARK: - QueryKey

extension PlanetaryRequest {
	
	struct QueryKey: RawRepresentable{
		static let thumbs 		= QueryKey(rawValue: "thumbs")
		static let startDate 	= QueryKey(rawValue: "start_date")
		static let endDate 		= QueryKey(rawValue: "end_date")
		static let infoDate		= QueryKey(rawValue: "date")
		
		var rawValue: String
		var key: String {
			rawValue
		}
	}

	///
	/// Create Query Parameter
	/// - Parameters:
	///   - value: Query Parameter value
	///   - queryKey: Query Parameter key
	///   - Returns: A `QueryParameter`
	///
	func queryParameter(_ value: String, forKey queryKey: QueryKey) -> QueryParameter {
		QueryParameter(name: queryKey.key, value: value)
	}
}
