//
//  PlanetaryDataProvider.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation
import Combine

final class PlanetaryDataProvider: ObservableObject {
	
	// MARK: - Propeties

	///
	/// The set in which to store this AnyCancellable.
	///
	private var subscriptions = Set<AnyCancellable>()

	///
	/// Data is Fething to show loader or simmer effect
	///
	@Published var isLoading: Bool = true
	
	///
	/// the planetary  model
	///
	@Published var planetary: Planetary? = nil

	///
	/// the fetch curent planetary by date
	///
	@Published var date: Date = .today {
		didSet {
			if APIManager.shared.monitor.isConnected {
				fetchPlanetary()
			}
			
		}
	}
	
	//MARK: - Instance
	
	init(planetary aPlanetary: Planetary? = nil) {
		isLoading = aPlanetary == nil
		planetary =  aPlanetary
	}
	
	//MARK: -

	///
	/// fech current Planetary and search other Planetary by date
	///
	func fetchPlanetary() {
		isLoading = true
		let aReqeust = PlanetaryRequest(date: date ~ .podFullDateOnly, isThumbs: true)
		aReqeust.perform(Planetary.self)
			.eraseToAnyPublisher()
			.receive(on: RunLoop.main)
			.sink(receiveCompletion: { [weak self] completion in
				if case .failure(let anError) = completion {
					debugPrint("Reqeust Failed 👉 \(anError)")
					self?.isLoading = false
				}
				
			}, receiveValue: {[weak self] response in
				self?.isLoading = false
				self?.planetary = response
			
			})
			.store(in: &subscriptions)
	}

}
