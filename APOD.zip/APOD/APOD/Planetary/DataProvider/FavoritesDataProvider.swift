//
//  FavoritesDataProvider.swift
//  APOD
//
//  Created by Jitendra kumar on 14/08/22.
//

import Foundation
import Combine

final class FavoritesDataProvider: ObservableObject {
	
	
	// the key we're using to read/write in UserDefaults
	private let saveKey =  "Favorites"
	
	// the actual resorts the user has favorited
	private var plantaries: Set<String>

	init() {
		plantaries = []
		load()
	}
	
	// returns true if our set contains this Planetary
	func contains(_ planetary: Planetary?) -> Bool {
		guard let planetary = planetary else {
			return false
		}
		return plantaries.contains(planetary.title)
	}
	
	// adds the Planetary to our set, updates all views, and saves the change
	func add(_ planetary: Planetary?) {
		guard let planetary = planetary else {
			return
		}
		objectWillChange.send()
		plantaries.insert(planetary.title)
		save()
	}
	
	// removes the Planetary from our set, updates all views, and saves the change
	func remove(_ planetary: Planetary?) {
		guard let planetary = planetary else {
			return
		}
		objectWillChange.send()
		plantaries.remove(planetary.title)
		save()
	}
	
	// adds/remove the Planetary to our set, updates all views, and saves the change
	func toggleFavorite(_ planetary: Planetary?) {
		guard let planetary = planetary else {
			return
		}
		if contains(planetary) {
			remove(planetary)
		} else {
			add(planetary)
			
		}
	}
	
	func save() {
		let list = Array(plantaries)
		UserDefaults.standard.setValue(list, forKey: saveKey)
		UserDefaults.standard.synchronize()
	}
	
	func load() {
		if let list  = UserDefaults.standard.value(forKey: saveKey) as? [String] {
			plantaries = Set(list)
		} else {
			plantaries = []
		}
	}
}
