//
//  PlanetaryListDataProvider.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import Foundation
import Combine

final class PlanetaryListDataProvider : ObservableObject {

	// MARK: - Propeties

	///
	/// Data is Fething to show loader or simmer effect
	///
	@Published var isLoading: Bool

	///
	/// fetch planetary list from current date to preview date `previous 30 days`
	///
	@Published private var planetaryDays: Int = 30
	
	///
	/// list of planetary
	///
	@Published var planetaries:[Planetary] = []

	///
	/// list of planetary
	///
	@Published var searchList:[Planetary] = []

	///
	/// Local Search Planet List using name
	///
	@Published var searchText = "" {
		didSet {
			if isSearch {
				searchList = planetaries.filter({$0.title.localizedCaseInsensitiveContains(searchText)})
			} else {
				searchList = []
			}
		}
	}

	///
	/// The set in which to store this AnyCancellable.
	///
	private var subscriptions = Set<AnyCancellable>()
	
	///
	/// fetch planetary list from current date to preview date
	///
	var planetaryRequest: PlanetaryRequest?
	
	var isSearch: Bool {
		!searchText.isEmpty
	}
	
	//MARK: - Init
	
	init() {
		isLoading = true
		fetchPlanetaryList()
	}

	
	// MARK: -
	
	///
	/// fetch Planetary list data
	///
	func fetchPlanetaryList() {
		searchText = ""
		searchList.removeAll()
		isLoading = true
		let startDate =  Date.today.date(daysFromToday: planetaryDays) ~ .podFullDateOnly
		let endDate  = Date.today.date(daysFromToday: 1) ~ .podFullDateOnly
		let aReqeust = PlanetaryRequest(statDate: startDate, endDate: endDate, isThumbs: true)
		aReqeust.perform([Planetary].self)
			.tryMap({$0.sorted(by: {$0.date.compare($1.date) == .orderedDescending})})
			.receive(on: RunLoop.main)
			.sink(receiveCompletion: { [weak self] completion in
				if case .failure(let anError) = completion {
					debugPrint("Reqeust Failed 👉 \(anError)")
					self?.isLoading = false
				}
				
			}, receiveValue: {[weak self] response in
				debugPrint("response 👉 \(response)")
				self?.isLoading = false
				self?.planetaries = response
				
			})
			.store(in: &subscriptions)
	}
					
}
