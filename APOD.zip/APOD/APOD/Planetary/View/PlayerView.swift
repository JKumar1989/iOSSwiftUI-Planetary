//
//  PlayerView.swift
//  APOD
//
//  Created by Jitendra kumar on 15/08/22.
//

import SwiftUI
import AVKit

struct PlayerView: View {
	
	@State private var isPlaying: Bool = false
	@State private var player: AVPlayer
	private var playerItem: AVPlayerItem?
	
	init(url: URL) {
		playerItem = AVPlayerItem(url: url)
		player = AVPlayer(playerItem: playerItem)
	}
	
	var body: some View {
		VStack {
			VideoPlayer(player: player)
				.edgesIgnoringSafeArea(.all)
				.onAppear{
					play()
				}.onDisappear{
					pause()
				}
		}
	}
	
	@MainActor
	func play() {
		withAnimation {
			isPlaying = true
			player.play()
		}
		
	}
	@MainActor
	func pause() {
		withAnimation {
			isPlaying = false
			player.pause()
		}
		
	}
}

struct PlayerView_Previews: PreviewProvider {
    static var previews: some View {
		PlayerView(url: URL(string: "https://www.youtube.com/embed/rFDjAfwmWKM?rel=0")!)
    }
}
