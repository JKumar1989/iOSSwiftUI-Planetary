//
//  PlanetaryListView.swift
//  APOD
//
//  Created by Jitendra kumar on 09/08/22.
//

import SwiftUI

struct PlanetaryListView: View {
	@StateObject var dataPrvider = PlanetaryListDataProvider()
	@StateObject var favortiesProvider = FavoritesDataProvider()
	
	
	var body: some View {
		NavigationView {
			VStack {
				ScrollView(.vertical, showsIndicators: false) {
					if dataPrvider.isLoading {
						let count  = Int(round(size.height / 80))
						ForEach(0..<count, id: \.self) { _ in
							PlanetaryCardView(planetary: Planetary.placeholderList[0],
											  isFavorite: false,
											  isLoading:true)
						}
						
					} else {
						ForEach(dataPrvider.isSearch ? $dataPrvider.searchList : $dataPrvider.planetaries, id: \.id) { $planetary in
							NavigationLink {
								PlanetaryDetailView()
									.environmentObject(PlanetaryDataProvider(planetary: planetary))
							} label: {
								PlanetaryCardView(planetary: planetary,
												  isFavorite: favortiesProvider.contains(planetary),
												  isLoading: dataPrvider.isLoading)
								
							}
						}
					}
				}
				
			}.padding(10)
				.navigationBarTitle("Planetary", displayMode: .inline)
				.searchable(text: $dataPrvider.searchText, prompt: "Enter planet name")
				.cornerRadius(5)
				.disabled(dataPrvider.isLoading)
		}
		.environmentObject(favortiesProvider)
		
		
	}
	
}

struct PlanetaryListView_Previews: PreviewProvider {
	static var previews: some View {
		NavigationView {
			PlanetaryListView()
				.navigationBarHidden(true)
		}
	}
}

