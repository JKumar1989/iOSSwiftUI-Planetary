//
//  PlanetaryCardView.swift
//  APOD
//
//  Created by Jitendra kumar on 11/08/22.
//

import SwiftUI

struct PlanetaryCardView: View {
	
	///
	/// the planet model
	///
	var planetary: Planetary
	
	///
	/// the planet is Favorite or not
	///
	var isFavorite: Bool
	
	///
	/// the planet dat requesting or loaded
	///
	var isLoading: Bool
	
	///
	/// `colorScheme`
	///
	@Environment(\.colorScheme) var colorScheme
	
	
	
	var body: some View {
		
		HStack(spacing: 15) {
			
			ZStack(alignment: .topTrailing) {
				AsyncImage(url: planetary.thumbnailURL) { image in
					image.resizable()
						.clipShape(RoundedRectangle(cornerRadius: 5))
						.unredacted()
				} placeholder: {
					RoundedRectangle(cornerRadius: 5)
						.fill(Color.secondary
							.opacity(0.4))
						.overlay {
							ProgressView()
								.unredacted()
						}
				}
				Image(systemName: isFavorite ? "heart.fill" : "heart")
					.font(.body)
					.foregroundColor( isFavorite ? .red : .secondary)
					.padding(8)
					.background(
						Circle()
							.fill(.white)
							.frame(width: 30, height: 30)
							.shadow(radius: 2)
					)
					.padding(.trailing, 5)
					.padding(.top, 5)
			}
			.frame(width: 95, height: 100)
			.redacted(reason: isLoading ? .placeholder : [])
			
			
			VStack(alignment: .leading, spacing: 8) {
				HStack(spacing: 4) {
					Text(planetary.title)
						.foregroundColor(.primary)
						.font(.title3)
						.fontWeight(.semibold)
						.lineLimit(1)
					
					
					Text(planetary.date, style: .date)
						.font(.caption)
						.foregroundColor(.secondary)
						.padding(.trailing, 1)
						.frame( alignment: .trailing)
				}
				
				Text(planetary.description)
					.font(.callout)
					.foregroundColor(.gray)
					.lineLimit(4)
					.multilineTextAlignment(.leading)
					.padding(.bottom, 5)
				
				
			}
			.padding(.bottom, 6)
		}
		
		.padding(10)
		.background(
			RoundedRectangle(cornerRadius: 5)
				.fill(Color(UIColor.systemBackground))
				.border(Color(UIColor.systemBackground), width: 0.5)
				.shadow(radius: 2)
			
		)
		.redacted(reason: isLoading ? .placeholder : [])
		
		
		
	}
}

struct PlanetaryCardView_Previews: PreviewProvider {
	static var previews: some View {
		PlanetaryCardView(planetary: Planetary.placeholderList[0], isFavorite: false, isLoading: false)
			.previewDevice("iPhone 13")
		
	}
}
