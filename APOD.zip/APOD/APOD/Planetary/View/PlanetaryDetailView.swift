//
//  PlanetaryDetailView.swift
//  APOD
//
//  Created by Jitendra kumar on 10/08/22.
//

import SwiftUI


struct PlanetaryDetailView: View {
	@EnvironmentObject var dataPrvider: PlanetaryDataProvider
	@EnvironmentObject var favortiesProvider: FavoritesDataProvider
	@State private var showPicker = false
	
	var hasFavorite : Bool {
		favortiesProvider.contains(dataPrvider.planetary)
	}
	
	
	// UI Body
	
	var body: some View {
			VStack {
				if showPicker {
					datePickerView(selection: $dataPrvider.date, in: Calendar.current.planteryDateRange)
				}
				ScrollView(.vertical, showsIndicators: false) {
					VStack {
						// Image video  View
						ZStack(alignment: .topTrailing) {
							if dataPrvider.planetary?.mediaType == .image {
								AsyncImage(url: dataPrvider.planetary?.thumbnailURL) { image in
									image.resizable()
										.clipShape(RoundedRectangle(cornerRadius: 5))
										.unredacted()
								} placeholder: {
									RoundedRectangle(cornerRadius: 5)
										.fill(Color.secondary
											.opacity(0.4))
										.overlay {
											ProgressView()
												.unredacted()
										}
									
								}
								
							} else if dataPrvider.planetary?.mediaType == .video {
								if let mediaUrl = dataPrvider.planetary?.mediaUrl,
								   let url = URL(string: mediaUrl) {
									PlayerView(url: url)
										.cornerRadius(5)
								}
							}
							
							
							//Favorite Button
							Button(action: {
								withAnimation {
									favortiesProvider.toggleFavorite(dataPrvider.planetary)
								}
							}, label: {
								Image(systemName:favortiesProvider.contains(dataPrvider.planetary) ? "heart.fill" : "heart")
									.font(.title2)
									.foregroundColor(favortiesProvider.contains(dataPrvider.planetary) ? .red : .secondary)
									.padding(8)
									.background(
										Circle()
											.fill(.white)
											.frame(width: 40, height: 40)
											.shadow(radius: 2)
									)
									.padding(.trailing, 9)
									.padding(.top, 10)
							}).disabled(dataPrvider.isLoading)

						}
						.frame(height: 280)
						.redacted(reason: dataPrvider.isLoading ? .placeholder : [])
						
						// Text  View
						VStack(alignment: .leading, spacing: 8) {
							HStack(spacing: 4) {
								Text(dataPrvider.planetary?.title ?? "")
									.font(.title3)
									.fontWeight(.semibold)
									.foregroundColor(.primary)
									.lineLimit(1)
								
								
								Text(dataPrvider.planetary?.date ?? Date.today, style: .date)
									.font(.caption)
									.foregroundColor(.secondary)
									.padding(.trailing, 1)
									.frame( alignment: .trailing)
							}
							
							Text(dataPrvider.planetary?.description ?? "")
								.font(.body)
								.foregroundColor(.gray)
								.multilineTextAlignment(.leading)
						}
						
					}
					.redacted(reason: dataPrvider.isLoading ? .placeholder : [])
					
				}
				.padding(.horizontal, 15)
			}
			.navigationBarTitle("Planetary Info", displayMode: .inline)
			.toolbar {
				ToolbarItem(placement: .navigationBarTrailing) {
					Button {
						withAnimation {
							showPicker.toggle()
						}
					} label: {
						Image(systemName: "magnifyingglass")
							.foregroundColor(.red)
					}
				}
				
			}
			
		
	}

}

struct PlanetaryDetailView_Previews: PreviewProvider {
	static var previews: some View {
		NavigationView {
			PlanetaryDetailView()
				.navigationBarHidden(true)
				.environmentObject(PlanetaryDataProvider(planetary: Planetary.placeholderList[0]))
		}.environmentObject(FavoritesDataProvider())
		
	}
}

//MARK: -

extension View {
	var size: CGSize  {
		UIScreen.main.bounds.size
	}
	
	@ViewBuilder
	func datePickerView(selection: Binding<Date>,
						in range: ClosedRange<Date> = Calendar.current.planteryMinDate...Date.today,
						displayedComponents : DatePicker.Components = [.date],
						accentColor: Color = .red) -> some View {
		
		DatePicker("",
				   selection: selection,
				   in: Calendar.current.planteryDateRange,
				   displayedComponents: .date)
		.labelsHidden()
		.accentColor(accentColor)
		.datePickerStyle(GraphicalDatePickerStyle())
		
	}
	
}
