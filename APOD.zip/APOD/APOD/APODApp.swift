//
//  APODApp.swift
//  APOD
//
//  Created by Jitendra kumar on 09/08/22.
//

import SwiftUI

@main
struct APODApp: App {
	@UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
			PlanetaryListView()
		}
    }
}

class AppDelegate: UIResponder, UIApplicationDelegate {

	func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
		APIManager.shared.monitor.start()
		return true
	}
}
